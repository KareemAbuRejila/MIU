const Pair = require('./Item.js');
const Tree = require('./BinaryTree.js');
const Iter = require('./BinaryTreeIterator.js');

function compareKeys(key1, key2) {
    return key1 - key2;
}
class BinarySearchTree {
    constructor(comparator=compareKeys) {
        this._binTree = new Tree.BinaryTree();
        this._comparator = comparator;
    }
    compare(key1, key2) {
        return this._comparator(key1, key2);
    }
    size() {
        return this._binTree.size();
    }
    isEmpty() {
        return this._binTree.isEmpty();
    }
    root() {
        return this._binTree.root();
    }
    isRoot(p) {
        return this._binTree.isRoot(p);
    }
    parent(p) {
        return this._binTree.parent(p);
    }
    leftChild(p) {
        return this._binTree.leftChild(p);
    }
    rightChild(p) {
        return this._binTree.rightChild(p);
    }
    isLeftChild(p) {
        return this._binTree.isLeftChild(p);
    }
    isRightChild(p) {
        return this._binTree.isRightChild(p);
    }
    sibling(p) {
        return this._binTree.sibling(p);
    }
    isExternal(p) {
        return this._binTree.isExternal(p);
    }
    isInternal(p) {
        return this._binTree.isInternal(p);
    }
    _findPosition(k, p) {
        let diff = this.compare(k, p.element().key());
        if (diff < 0) {
            let left = this._binTree.leftChild(p);
            if (this.isExternal(left)) {
                return p;
            } else {
                return this._findPosition(k, left);
            }
        } else if (diff > 0) {
            let right = this._binTree.rightChild(p);
            if (this.isExternal(right)) {
                return p;
            } else {
                return this._findPosition(k, right);
            }
        } else {  // key k is in position p
            return p;  
        }
    }
    replaceValue(k, value) {
        if (this.isEmpty()) {
            return null;
        } else {
            let p = this._findPosition(k, this.root());
            if (p.element().key() != k) { // key k is not in the BST
                return null;
            } else {
                p._value = value;
                return p;
            }
        }
    }
    insertItem(k, value) {
        if (this.isEmpty()) {
            return this._binTree.insertRoot(new Pair.Item(k, value));
        } else {
            let p = this._findPosition(k, this.root());
            let diff = this.compare(k, p.element().key());
            if (diff == 0) { // k is already in the tree
                p.element()._value = value; // update/replace the value
                return p;
            } else {
                let newItem = new Pair.Item(k, value);
                if (diff < 0) {
                    return this._binTree.insertLeft(p, newItem);
                } else { 
                    return this._binTree.insertRight(p, newItem);
                }
            }
        }
    }
    _findPosition2Remove(k) {
        if (this.isEmpty()) { // key k is not in the BST
            return null;
        }
        let v = this._findPosition(k, this.root());
        if (v.element().key() != k) { // key k is not in the BST
            return null;
        }
        let r = v;
        let left = this._binTree.leftChild(v);
        let right = this._binTree.rightChild(v);
        if (this._binTree.isInternal(left) && this._binTree.isInternal(right)) {
            r = this._findPosition(k, left);  // keep looking down the left subtree for deletion node
            this._binTree.swapElements(v, r);
        }
        return r;
    }
    remove(p) {
        return this._binTree.remove(p);
    }
    removeItem(k) {
        let v = this._findPosition2Remove(k);
        if (null == v) {
            return null;
        }
        this.remove(v);
        return v.element().value();
    }
    findValue(k) {
        if (this.isEmpty()) { // key k is not in the BST
            return null;
        }
        let p = this._findPosition(k, this.root());
        if (p.element().key() != k) { // key not found
            return null;
        } else {
            return p.element().value();
        }
    }
    items() {
        return new Iter.BinaryTreeIterator(this, 0);
    }
    keys() {
        return new Iter.BinaryTreeIterator(this, 1);
    }
    values() {
        return new Iter.BinaryTreeIterator(this, 2);
    }
}

exports.BinarySearchTree = BinarySearchTree;