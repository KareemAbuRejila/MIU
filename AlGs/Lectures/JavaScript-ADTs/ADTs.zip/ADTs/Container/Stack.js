const List = require('./List.js');

class Stack { // implemented as a linear hash table
    constructor () {
        this._stack = new List.List();
    }
    push(elem) {
        this._stack.insertFirst(elem);
    }
    pop() {
        if (this.isEmpty()) {
            throw new Error("Attempted pop() on an empty Stack");
        }
        return this._stack.remove(this._stack.first());
    }
    top() {
        if (this.isEmpty()) {
            throw new Error("Attempted top() on an empty Stack");
        }
        return this._stack.first().element();
    }
    toString() {
        let str = this._stack.toString();
        return str;
    }
    size() {
        return this._stack.size();
    }
    isEmpty() {
        return this._stack.isEmpty();
    }
}

exports.Stack = Stack;
