const List = require('./List.js');

class Queue { // implemented as a linear hash table
    constructor () {
        this._queue = new List.List();
    }
    enqueue(elem) {
        this._queue.insertLast(elem);
    }
    dequeue() {
        if (this.isEmpty()) {
            throw new Error("Attempted dequeue() on an empty Queue");
        }
        return this._queue.remove(this._queue.first());
    }
    front() {
        if (this.isEmpty()) {
            throw new Error("Attempted front() on an empty Queue");
        }
        return this._queue.first().element();
    }
    toString() {
        let str = this._queue.toString();
        return str;
    }
    size() {
        return this._queue.size();
    }
    isEmpty() {
        return this._queue.isEmpty();
    }
}

exports.Queue = Queue;
