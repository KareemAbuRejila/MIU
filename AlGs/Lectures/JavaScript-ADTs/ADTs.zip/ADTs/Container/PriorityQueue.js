const Tree = require('./MinHeap.js');

class Item {
    constructor (key, value) {
        this._key = key;
        this._value = value;
    }
    key() {
        return this._key;
    }
    value() {
        return this._value;
    }
    toString() {
        return "(" + this._key + ", " + this._value + ")";
    }
}
function compareItems(item1, item2) {
    return item1.key() - item2.key();
}

class PriorityQueue {
    constructor(initSize=20, compare=compareItems ) {
        this._heap = new Tree.MinHeap(initSize, compare);
    }
    insertItem(key, value) { // returns the Position containing new Item
        let newItem = new Item(key, value);
        return this._heap.insert(newItem);
    }
    removeMin() {
        let item = this._heap.removeMin();
        return item.value();
    }
    minKey() {
        let item = this._heap.minimum();
        return item.key();
    }
    minElement() {
        let item = this._heap.minimum();
        return item.value();
    }
    size() {
        return this._heap.size();
    }
    isEmpty() {
        return this._heap.isEmpty();
    }
    numComparisons() {
        return this._heap.numComparisons();
    }
    numSwaps() {
        return this._heap.numSwaps();
    }
    toString() {
        return this._heap.toString();
    }
}

exports.PriorityQueue = PriorityQueue;