import React from 'react';

export const SaveKey = React.createContext('');
