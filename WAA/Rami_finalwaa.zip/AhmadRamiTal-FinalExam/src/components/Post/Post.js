import React, { useContext } from 'react';
import { LikedPosts } from '../../store/LikedPosts';

import './Post.css';

const Post = (props) => {

    const { likedPosts, setLikedPosts } = useContext(LikedPosts);

    return (
        <article className="Post" onClick={props.clicked}>
            <h1>{props.title}</h1>
            <div className="Info">
                <div className="Author">{props.author}</div>
           
            </div>
            {
                likedPosts.includes(props.id)
                    ?
                    <button onClick={() => { 
                       
                    console.log('ANSWER Task 1');
                        var tempindex = likedPosts.indexOf(props.id);
                        if (tempindex > -1) {  
                            likedPosts.splice(tempindex, 1);
                        }
                         console.log(likedPosts);
                    }}>
                        Unfollow </button>
                    :
                    <button onClick={() => {
                        setLikedPosts([...likedPosts, props.id]) ; 
                          console.log(likedPosts);
                     }}>
                        Follow </button>}
        </article>
    );
}

export default Post;