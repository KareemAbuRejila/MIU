import React, { useContext, useEffect, useRef, useState } from 'react';
import { SaveKey } from '../../store/SaveKey';
 
import './Status.css';

const Status = (props) => {

  
  
    const newPostForm = useRef();

    const [status, setstatus] = useState(''); 
    const {saveKey, setSaveKey } = useContext(SaveKey);
       
    

    useEffect(() => {
       console.log("Answer Task 6 Bonus");
      const form = newPostForm.current
      form['content'].value=saveKey; 
    }, []); 
 

    const PostDataHandler = () => {
       console.log("Answer Task 3")
        const form = newPostForm.current
        setstatus(form['content'].value);
       
    }


    return (
        <div className="NewPost">
            
            <form ref={newPostForm}>
                <textarea  rows="4" label={'content'} name={'content'}  onChange={(event) => setSaveKey(   event.target.value )}   />

            </form>
            
            <button onClick={PostDataHandler}>Update Status </button>
           
            <label>Status: {status} </label>
                
   
        </div>
    );
}
 export default Status;