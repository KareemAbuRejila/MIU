import React, { useContext, useEffect , useState} from 'react';
import axios from 'axios'; 
import './Following.css';  
import { LikedPosts } from '../../store/LikedPosts';
import { APIConfig } from '../../store/API-Config';

const Following = (props) => {

     const { likedPosts, setLikedPosts} = useContext(LikedPosts);
     const APIs = useContext(APIConfig);
     const postAPI = APIs.postAPI;
 
     const [posts, setPosts] = useState([]);
    
     
     function fetchPostsHandler() {
      const headers = {
            'Access-Control-Allow-Origin': '*',  }
        axios(postAPI, { headers })
            .then(response => {
                console.log("Answer Task 4")
               let newList =[];
               likedPosts.forEach(element => {

               newList.push( response.data.find((item) => item.id === element));
               });
              
                setPosts(newList);
     
              
            })
            .catch(error => {
                
            })
 
    }

     
    useEffect(fetchPostsHandler, [props]); 
   
   
 
 
    const rposts = posts.map(post => {
        return     <div className="FullPost" key={post.id} >
                    <h1>{post.title}</h1>
                    <p>{post.content}</p>
               
                  
                    <button onClick={() => { 
                    console.log("Answer Task 5");
                      var tempindex = likedPosts.indexOf(post.id);
                        if (tempindex > -1) {  
                            likedPosts.splice(tempindex, 1);
                        }
                        console.log(likedPosts);
                        props.history.push('/following'); 
                    }}>
                        Unfollow </button>
                    
                </div>
        
       
         
    });

  
    return (
        <div>
 
            <section className="Posts">
                <h1>Followed Posts</h1> 
            </section>

            <section className="Posts">
            {rposts}
            </section>
          
        </div>

    );
}

export default Following;
