import React from 'react';

export const Test = React.memo((props) => {
    //const renders = useRef(0);//removed by me to remove warning
    console.log('renders: ');

    return <button onClick={props.increment}> Test</button>  // increnet 1 
});