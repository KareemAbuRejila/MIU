package com.example.demo.repository;

import com.example.demo.domain.Post;
import org.springframework.stereotype.Repository;

import java.util.*;
import java.util.stream.IntStream;

@Repository
public class PostRepositoryImpl implements PostRepository{

    List<Post> posts = new ArrayList<>(Arrays.asList(new Post(1,"MIU","Its awesome","Tran"),new Post(2,"Mansif","Amazing","Aldini")));


    @Override
    public List<Post> getAll(){
        return posts;
    }

    @Override
    public Optional<Post> getById(long i){
        return
        posts.stream()
                .filter(p -> p.getId() == i )
                .findFirst();
    }

    @Override
    public void addPost(Post p){
        if(!hasId(p))
            p.setId(posts.size()+1); // give it the last index if it exsits
        posts.add(p);
    }

    @Override
    public void deletePost(long id){
        for (Post p : posts){
            if(p.getId()==id){
                posts.remove(p);
                break;
            }
        }
    }

    /**
     * If hasId is true that means it does not exist
     *
     * @param pe
     * @return
     */
    public boolean hasId(Post pe){
             Optional<Post> check = getById(pe.getId());
             return check == null;
    }



}
