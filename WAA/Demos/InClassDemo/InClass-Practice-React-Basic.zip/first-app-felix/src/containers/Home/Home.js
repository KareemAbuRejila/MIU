import React, { useState } from 'react';
import User from '../../components/User/User';
import './Home.css';

const Home = () => {

    const [selectedId, setId] = useState(null);
    const [text , setText] = useState("");
    const [users, setUsers] = useState(
        [
            { id: 0, name: "Dean" },
            { id: 1, name: "Milton" },
            { id: 2, name: "Maher" },
            { id: 3, name: "Nichelos" }
        ]
    );

    const deleteUsers = () => {
        setUsers([]);
    }

    const getId = (id) => {
        setId(id);
    }

    const userList = users.map(u => {
        return <User
            key={u.id}
            id={u.id}
            name={u.name}
            clicked={ () => {getId(u.id)}}
        />
    });

    const changeNameHandler = (name) => {
        const updatedList = [...users];
        updatedList[selectedId].name = text;
        setUsers(updatedList);
    } 


    return (
        <div className="Home">
            <section>
             {userList}
            </section>
            <section>
               {text}
            </section>

            <section>
                <input type="text" value={selectedId} onChange={(event) => setId(event.target.value)}/>
                <input type="text"  onChange={(event) => setText(event.target.value)}/>

                <button onClick={deleteUsers}> DeleteUsers</button>
                <button onClick={changeNameHandler}> Change Name</button>
            </section>
        </div>
    );

}


export default Home;


