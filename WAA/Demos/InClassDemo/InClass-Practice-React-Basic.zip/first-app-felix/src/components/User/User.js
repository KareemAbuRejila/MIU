import React from 'react';
import './User.css';


const User = (props) => {
return(

    <div className="User"  onClick={props.clicked}>
        <p> Id: {props.id}</p>
        <p> Name: {props.name}</p>
    </div>
);
    

}

export default User;