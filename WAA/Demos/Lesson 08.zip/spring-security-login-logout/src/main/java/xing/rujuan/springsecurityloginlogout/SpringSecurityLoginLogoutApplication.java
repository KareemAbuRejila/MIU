package xing.rujuan.springsecurityloginlogout;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSecurityLoginLogoutApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringSecurityLoginLogoutApplication.class, args);
    }

}
