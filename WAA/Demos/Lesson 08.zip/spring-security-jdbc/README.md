Spring Security - JDBCAuthentication
1. Schema
https://docs.spring.io/spring-security/site/docs/current/reference/html5/#appendix-schema