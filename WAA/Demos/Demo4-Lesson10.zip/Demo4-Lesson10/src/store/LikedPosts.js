import React from 'react';

export const LikedPosts = React.createContext([]);
