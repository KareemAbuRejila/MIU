import React from 'react';

export const StatusStore=React.createContext('');