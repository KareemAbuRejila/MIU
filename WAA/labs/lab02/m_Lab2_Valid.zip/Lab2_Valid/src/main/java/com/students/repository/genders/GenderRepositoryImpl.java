package com.students.repository.genders;

import com.students.domain.Gander;

import java.util.ArrayList;
import java.util.List;

public class GenderRepositoryImpl implements GenderRepository{


    @Override
    public Gander getOneGander(int id) {
        return null;
    }

    @Override
    public List<Gander> getAllGanders() {
        return null;
    }
}
