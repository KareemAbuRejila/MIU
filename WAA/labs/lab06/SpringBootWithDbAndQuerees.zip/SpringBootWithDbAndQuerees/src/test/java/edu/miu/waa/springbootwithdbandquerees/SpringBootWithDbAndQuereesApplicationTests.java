package edu.miu.waa.springbootwithdbandquerees;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootWithDbAndQuereesApplicationTests {

    @Test
    void contextLoads() {
    }

}
