package edu.miu.waa.springbootwithdbandquerees;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootWithDbAndQuereesApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringBootWithDbAndQuereesApplication.class, args);
    }

}
