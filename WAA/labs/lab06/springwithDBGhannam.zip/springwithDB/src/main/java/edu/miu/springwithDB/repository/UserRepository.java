package edu.miu.springwithDB.repository;

import edu.miu.springwithDB.domain.User;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import javax.persistence.NamedQueries;
import java.util.List;

public interface UserRepository extends CrudRepository <User, Long> {
@Query(value = "select u from User u where u.posts.size>1")
    public List<User> getUsersGTOnePost();

}
