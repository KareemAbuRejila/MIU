package edu.miu.springwithDB.domain;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import javax.persistence.*;
import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class User {
    @Id
    //@GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "USER_ID")
    long id;
    String name;
    @OneToMany(cascade = CascadeType.ALL)
// FetchMode.JOIN will do eager load also
    @Fetch(FetchMode.JOIN)
    @JoinTable(name = "UserPosts")
    List <Post> posts;
}
