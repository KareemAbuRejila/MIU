package edu.miu.springwithDB;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringwithApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringwithApplication.class, args);
    }

}
