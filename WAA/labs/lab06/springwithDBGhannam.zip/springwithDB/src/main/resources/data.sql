    INSERT into USER (USER_id,name) values (1,'Ahmed');


    INSERT into POST (POST_id, title, content, author) VALUES (1, 'MIU','Life is structured in layers','Dean');
    INSERT into POST (Post_id, title, content, author) VALUES (2, 'React','React is a good SPA library','Dean');
    INSERT into POST (Post_id, title, content, author) VALUES (3, 'Spring','Spring is awesome','Dean');
    Insert into User_Posts(USER_USER_ID, POSTs_POST_ID) values (1,1);
    Insert into User_Posts(USER_USER_ID, Posts_POST_ID) values (1,2);