package edu.miu.waa.secondspringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecondSpringBootApplicationTests {

    @Test
    void contextLoads() {
    }

}
