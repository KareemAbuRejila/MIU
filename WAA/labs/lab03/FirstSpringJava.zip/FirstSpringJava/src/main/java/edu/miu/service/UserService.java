package edu.miu.service;

import edu.miu.domain.User;

public interface UserService {

    public User getUser(int id);
}
