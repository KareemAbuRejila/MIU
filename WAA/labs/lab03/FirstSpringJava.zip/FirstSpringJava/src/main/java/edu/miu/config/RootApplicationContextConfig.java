package edu.miu.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("edu.miu")
public class RootApplicationContextConfig {


}
