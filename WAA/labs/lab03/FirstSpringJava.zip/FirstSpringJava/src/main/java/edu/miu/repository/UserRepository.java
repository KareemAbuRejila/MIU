package edu.miu.repository;

import edu.miu.domain.User;

public interface UserRepository {

    public User getUser(int id);
}
