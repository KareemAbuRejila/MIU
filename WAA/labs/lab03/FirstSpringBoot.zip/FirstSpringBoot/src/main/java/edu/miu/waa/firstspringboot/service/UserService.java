package edu.miu.waa.firstspringboot.service;


import edu.miu.waa.firstspringboot.domain.User;

public interface UserService {

    public User getUser(int id);
}
