package edu.miu.waa.firstspringboot.service;


import edu.miu.waa.firstspringboot.domain.User;
import edu.miu.waa.firstspringboot.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class UserServiceImpl implements UserService{

    @Autowired
    UserRepository userRepository;

    @Override
    public User getUser(int id) {
        return userRepository.getUser(id);
    }
}
