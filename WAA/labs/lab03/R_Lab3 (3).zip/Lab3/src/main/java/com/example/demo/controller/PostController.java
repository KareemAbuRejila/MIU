package com.example.demo.controller;


import com.example.demo.domain.Post;
import com.example.demo.service.PostService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


import java.util.List;

@RestController
@RequestMapping("/post")
public class PostController {


    @Autowired
    PostService postService;

    @GetMapping("/")
    public List<Post> getAll()
    {
        return postService.getAll();
    }

    @GetMapping("/{id}")
    public Post getone(@PathVariable int id)
    {
        return postService.getById(id);
    }

    @PostMapping(value="/")
    public Post addpost( @ModelAttribute Post post)
    { 
        return postService.addPost(post);
    }




    @DeleteMapping(value="/{id}")
    public boolean deletepost(@PathVariable int id)
    {
        return postService.removePost(id);
    }
}
