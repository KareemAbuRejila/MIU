package com.example.demo.repository;


import com.example.demo.domain.Post;

import java.util.List;

public interface PostRepository {

    public List<Post> getAll();


    public Post getById(int id);

    public Post addPost(Post post);
    public boolean removePost(int id);
}
