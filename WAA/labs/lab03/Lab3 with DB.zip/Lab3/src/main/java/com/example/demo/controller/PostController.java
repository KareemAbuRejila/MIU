package com.example.demo.controller;


import com.example.demo.domain.Post;
import com.example.demo.service.PostService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping(path="post")
public class PostController {


    @Autowired
    PostService postService;

    @RequestMapping(method=RequestMethod.GET,produces = "application/json")
    public List<Post> getAll()
    {
        return postService.getAll();
    }


    @RequestMapping(value="/{id}",method=RequestMethod.GET,produces = "application/json")
    public Optional<Post> getone(@PathVariable Long id)
    {
        return postService.getById(id);
    }

    @RequestMapping(method=RequestMethod.POST,produces = "application/json")
    public boolean addpost( @RequestBody Post post)
    {
        System.out.println(post.getId());
        return postService.addPost(post);
    }


    @RequestMapping(value="/{id}",method=RequestMethod.DELETE,produces = "application/json")
    public boolean deletepost(@PathVariable Long id)
    {
        return postService.removePost(id);
    }
}
