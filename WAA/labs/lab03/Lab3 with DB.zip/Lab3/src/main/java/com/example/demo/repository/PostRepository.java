package com.example.demo.repository;


import com.example.demo.domain.Post;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PostRepository extends CrudRepository<Post,Long>
{


//    @Query(value = "SELECT e FROM Post e WHERE e.title = :title")
//    public List<Post> findByTitle(String title);
//
//    public Post getById(int id);
//    public Post addPost(Post post);
//    public boolean removePost(int id);
}
