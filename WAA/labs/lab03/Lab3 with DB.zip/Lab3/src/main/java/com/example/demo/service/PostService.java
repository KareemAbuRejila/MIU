package com.example.demo.service;


import com.example.demo.domain.Post;

import java.util.List;
import java.util.Optional;

public interface PostService {


    public List<Post> getAll();

    public Optional<Post>  getById(Long id);

    public boolean addPost(Post post);

    public boolean removePost(Long id);
}
