package com.example.demo.repository;


import com.example.demo.domain.Post;
import org.springframework.boot.autoconfigure.data.cassandra.CassandraReactiveRepositoriesAutoConfiguration;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Repository
public class PostRepositoryImpl implements PostRepository {

    List<Post> posts =new ArrayList<>(Arrays.asList(new Post(1,"MIU","Its awsome","Tran"),new Post(2,"Mansif","Amazing","Aldini")));


    @Override
    public List<Post> getAll(){
        return posts;
    }

    @Override

    public Post getById(int id){
        return posts.stream().filter(s->s.getId()==id).findFirst().orElse(null) ;
    }

    @Override
    public Post addPost(Post post){

         posts.add(post);
        return post;
    }

    @Override
    public boolean removePost(int id){

       try {
           var post=posts.stream().filter(s->s.getId()==id).findFirst().orElse(null);
        posts.remove(post);
        return true;
       }
       catch (Exception ex)
       {

           return false;
      }

    }
}
