DROP TABLE Post IF EXISTS;

CREATE TABLE Post(
	id Long PRIMARY KEY,

	content VARCHAR(50),
	 title VARCHAR(50),
	 author VARCHAR(50)
);

