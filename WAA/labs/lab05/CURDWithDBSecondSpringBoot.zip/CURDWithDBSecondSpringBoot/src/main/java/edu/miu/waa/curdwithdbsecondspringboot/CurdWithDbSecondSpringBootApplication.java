package edu.miu.waa.curdwithdbsecondspringboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CurdWithDbSecondSpringBootApplication {

    public static void main(String[] args) {
        SpringApplication.run(CurdWithDbSecondSpringBootApplication.class, args);
    }

}
