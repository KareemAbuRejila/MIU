package edu.miu.waa.curdwithdbsecondspringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CurdWithDbSecondSpringBootApplicationTests {

    @Test
    void contextLoads() {
    }

}
