import React, { useState } from 'react';

 import Student from '../../Components/Student/Student';
 
// import './Dashboard.css';


const Dashboard = () => {

    const [students,setStudents]=useState([{  major:"CS",name:"Rami",id:1},{  major:"CS",name:"test",id:2},  {  major:"CS",name:"test2",id:3}  ]);
    const [inputName,setInput]=useState("");

    function handleAdd()
    { 
     const temp = [...students];
     temp[0].name = inputName;
     setStudents(temp);
          
    }
    function handleChange(event)
    {
         setInput(event.target.value);
    }
    
    const stuList=students.map(stu=> <Student major={stu.major}     name={stu.name}  id={stu.id}   />);
        return (
            <div>

                <input  type="text" value={inputName}  onChange={handleChange}   />
                <button onClick={handleAdd}>Update Name</button>
             <section className="Student">
                  {stuList}
             </section>
             
            </div>
        );
    }

export default Dashboard;