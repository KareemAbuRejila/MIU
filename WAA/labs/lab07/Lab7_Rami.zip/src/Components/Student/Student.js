import React from 'react';

import './Student.css';

const Student = (stu) => (
    <article   >
 
 
    <div className="card">
    <h2> Student</h2>
        <p>ID: {stu.id}</p>
        <p>Name: {stu.name}</p>
        <p>Major: {stu.major}</p>
     </div>
  
     
    </article>
);

export default Student;