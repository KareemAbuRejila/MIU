package miu.main.service;

import miu.main.domain.Post;
import miu.main.domain.User;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface UserService {
    public List<User> getAllUsers();
    public User getUserById(long id);
    public User addUser(User u);
    public List<Post> getAllPosts(long id);
    public List<User> getUsersGTPosts();

}
