package miu.main.controller;

import miu.main.domain.Post;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import miu.main.service.PostService;

import java.util.List;
import java.util.Optional;


@CrossOrigin(origins = {"http://localhost:3000"})
@RestController
@RequestMapping("/post")
public class PostController {


    @Autowired
    PostService postService;

    @PreAuthorize("hasRole('ADMIN') or hasRole('USER')")
    @GetMapping
    public List<Post> getPosts(){
        List<Post> posts =  postService.findAll();
        return posts;
    }


    @PreAuthorize("hasRole('ADMIN') or hasRole('USER')")
    @GetMapping("/{id}")
    public Optional<Post> getPostById(@PathVariable String id){

        Optional<Post> p=  postService.findById(Long.parseLong(id));
        return  p;
    }
    @PreAuthorize("hasRole('ADMIN') or hasRole('USER')")
    @DeleteMapping("/{id}")
    public void deletePost(@PathVariable("id") long id )
    {
        postService.deletePostById(id);
    }

    @PreAuthorize("hasRole('ADMIN') or hasRole('USER')")
    @PutMapping("/{id}")
    public Post editPost(@PathVariable("id") long id,@RequestBody Post p)
    {

        return postService.editPost(p,id);
    }


}
