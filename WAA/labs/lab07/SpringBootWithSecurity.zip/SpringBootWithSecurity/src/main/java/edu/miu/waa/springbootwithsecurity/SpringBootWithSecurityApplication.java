package edu.miu.waa.springbootwithsecurity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootWithSecurityApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringBootWithSecurityApplication.class, args);
    }

}
