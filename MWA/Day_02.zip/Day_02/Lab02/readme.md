Assigment_2
This is The Second Day of MWA-CS572 Course.
Lab02