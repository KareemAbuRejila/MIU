package edu.mum.cs;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/placeOrder")
public class OrderServlet extends HttpServlet {

    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String productId = req.getParameter("productid");
        String productname = req.getParameter("productname");
        String quantity = req.getParameter("quantity");

        //creat order object
        //save to database
        req.setAttribute("orderno", "123456");
        System.out.println("===save to database===");
        //never forward
        //use redirect
//        req.getRequestDispatcher("thankyou.jsp").forward(req, resp);
        resp.sendRedirect("placeOrder?orderno=123456");
    }

    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setAttribute("orderno", req.getParameter("orderno"));
        req.getRequestDispatcher("WEB-INF/thankyou.jsp").forward(req, resp);
    }

}
